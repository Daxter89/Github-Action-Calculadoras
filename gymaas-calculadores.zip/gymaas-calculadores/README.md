## Gym Bro As A Service
Enllaç a l'[enunciat](https://bolder-equipment-678.notion.site/Gym-Bro-as-a-service-fe4381b1a4ca476b9595e67e9d80e2dd?pvs=4 "Gym Bro As A Service").
Jose - GET BODY MASS INDEX / GET IDEAL BODY WEIGHT
Xavi - GET BASAL METABOLIC RATE - GET A BODY SHAPE INDEX
Edwin - GET BODY FAT PERCENTAGE - GET TOTAL DAILY ENERGY EXPENDITURE
